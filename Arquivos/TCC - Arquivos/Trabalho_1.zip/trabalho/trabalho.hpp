#ifndef TRABALHO_HPP
#define TRABALHO_HPP

#include <string>

#define MAX_NAVIOS 100
#define MAX_BERCOS 20

// Estruturas de dados

typedef struct tSolucao
{
    int fo;
    int MAT[MAX_BERCOS][MAX_NAVIOS];
    int qtd_navio_no_berco[MAX_BERCOS];
} Solucao;

//Dados de entrada
int NUMNAVIOS; //numero de navios
int NUMBERCOS; //numero de bercos

int MAT_ATENDIMENTO[MAX_BERCOS][MAX_NAVIOS]; //matriz de atedimento BercosXNavios

int tempAbertura[MAX_BERCOS];
int tempFechamento[MAX_BERCOS];

int tempChegada[MAX_NAVIOS];
int tempSaida[MAX_NAVIOS];

int matInicioAtendimento[MAX_BERCOS][MAX_NAVIOS];
int matTerminoAtendimento[MAX_BERCOS][MAX_NAVIOS];

int vetTerminoAtendimento[MAX_BERCOS]; //do ultimo navio


//int vetTempChegadaOrd[MAX_NAVIOS];

//functions
void lerDados(std::string arq);

void testarDados(char *arq);

Solucao clonaSolucao(Solucao &s);

void calcFO(Solucao &s);

//heuristica
void heuConGul(Solucao &s);

void escreverSol(const Solucao &s, char *arq); //imprime na tela e no arquivo a solucao.

void ordenarPosicaoMenorTempoChegada(int vetTempChegadaOrd[MAX_NAVIOS]);

int totalViolacoesNavios(Solucao s);

int totalViolacoesBercos(Solucao s);

#endif /* TRABALHO_HPP */