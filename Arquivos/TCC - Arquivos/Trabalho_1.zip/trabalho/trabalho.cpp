//inclusões
#include <iostream>
#include <memory.h>
#include <time.h>
#include "trabalho.hpp"
#include <stdlib.h>
//#include <algorithm>

//definições
#define MAX(X, Y) ((X > Y) ? X : Y)
//#define MIN(X, Y) ((X < Y) ? X : Y) não usei por enquanto

#define PESO_TLNAVIO 100 //PENALIZACAO POR ULTRAPASSAR TEMPO LIMITE DO NAVIO NO PORTO.
#define PESO_TFBERCO 100 //PENALIZACAO POR ULTRAPASSAR TEMPO DE FECHAMENTO DO BERCO.

using namespace std;

int main(int argc, char const *argv[])
{
    Solucao s;
    lerDados("i05.txt"); //lê a instancia 1.
    //testarDados("teste.txt"); imprime um arquivo para verificar se a leitura dos dados está correta.

    clock_t h;
    double tempo;
    h = clock();
    heuConGul(s);
    calcFO(s);
    h = clock() - h;
    tempo = (double)h / CLOCKS_PER_SEC;
    cout << s.fo << "\n";
    printf("Construtiva Gulosa...: %.5f seg.\n", tempo);

    h = clock();
    for (int i = 0; i < 10000; i++)
    {
        heuConGul(s);
    }
    h = clock() - h;
    tempo = (double)h / CLOCKS_PER_SEC;
    printf("Tempo heuristica Construtiva Gulosa...: %.5f seg.\n", tempo);

    h = clock();
    for (int i = 0; i < 10000; i++)
    {
        calcFO(s);
    }
    h = clock() - h;
    tempo = (double)h / CLOCKS_PER_SEC;
    printf("Tempo calculo FO...: %.5f seg.\n", tempo);

    escreverSol(s,"Solucao.txt");
    return 0;
}

void lerDados(string arq)
{
    memset(&MAT_ATENDIMENTO, 0, sizeof(MAT_ATENDIMENTO));
    FILE *f = fopen(arq.c_str(), "r");

    fscanf(f, "%d %d\n", &NUMNAVIOS, &NUMBERCOS);

    for (int i = 0; i < NUMBERCOS; i++)
    {
        for (int j = 0; j < NUMNAVIOS; j++)
        {
            fscanf(f, "%d", &MAT_ATENDIMENTO[i][j]);
        }
    }

    for (int i = 0; i < NUMBERCOS; i++)
    {
        fscanf(f, "%d", &tempAbertura[i]);
        fscanf(f, "%d", &tempFechamento[i]);
    }
    for (int i = 0; i < NUMNAVIOS; i++)
    {
        fscanf(f, "%d", &tempChegada[i]);
    }
    for (int i = 0; i < NUMNAVIOS; i++)
    {
        fscanf(f, "%d", &tempSaida[i]);
    }
}

void testarDados(char *arq)
{
    FILE *f;
    if (arq == "")
        f = stdout;
    else
        f = fopen(arq, "w");

    fprintf(f, "%d %d\n", NUMNAVIOS, NUMBERCOS);

    for (int i = 0; i < NUMBERCOS; i++)
    {
        for (int j = 0; j < NUMNAVIOS; j++)
        {
            fprintf(f, "%d ", MAT_ATENDIMENTO[i][j]);
        }
        fprintf(f, "\n");
    }

    for (int i = 0; i < NUMBERCOS; i++)
    {
        fprintf(f, "%d ", tempAbertura[i]);
        fprintf(f, "%d ", tempFechamento[i]);
        fprintf(f, "\n");
    }

    for (int i = 0; i < NUMNAVIOS; i++)
    {
        fprintf(f, "%d ", tempChegada[i]);
    }
    fprintf(f, "\n");

    for (int i = 0; i < NUMNAVIOS; i++)
    {
        fprintf(f, "%d ", tempSaida[i]);
    }
    fclose(f);
}

Solucao clonaSolucao(Solucao &s)
{
    Solucao S;
    S.fo = s.fo;
    memcpy(S.MAT, s.MAT, sizeof(s.MAT));
    memcpy(&S.qtd_navio_no_berco, &s.qtd_navio_no_berco, sizeof(s.qtd_navio_no_berco));
    return S;
}

void heuConGul(Solucao &s)
{
    memset(&s.qtd_navio_no_berco, 0, sizeof(s.qtd_navio_no_berco));
    memset(&s.MAT, -1, sizeof(s.MAT));

    int j = 0;
    for (int i = 0; i < NUMNAVIOS; i++)
    {
        while (MAT_ATENDIMENTO[j][i] == 0)
        {
            j++;
            j = j % NUMBERCOS;
        }
        s.MAT[j][i] = i;
        s.qtd_navio_no_berco[j]++;
        j++;
    }

    for (int i = 0; i < NUMBERCOS; i++)
    {
        ordenarPosicaoMenorTempoChegada(s.MAT[i]);
    }
}

void ordenarPosicaoMenorTempoChegada(int vetTempChegadaOrd[MAX_NAVIOS])
{
    int flag, aux;
    flag = 1;

    while (flag)
    {
        flag = 0;
        for (int j = 0; j < NUMNAVIOS - 1; j++)
        {
            if (tempChegada[vetTempChegadaOrd[j]] > tempChegada[vetTempChegadaOrd[j + 1]])
            {
                flag = 1;
                aux = vetTempChegadaOrd[j];
                vetTempChegadaOrd[j] = vetTempChegadaOrd[j + 1];
                vetTempChegadaOrd[j + 1] = aux;
            }
        }
    }
}

void calcFO(Solucao &s)
{
    s.fo = 0; //inicia com valor 0.

    for (int i = 0; i < NUMBERCOS; i++)
    {
        vetTerminoAtendimento[i] = tempAbertura[i]; //começa com o tempo de abertura do berco.
    }

    memset(&matInicioAtendimento, 0, sizeof(matInicioAtendimento));

    for (int i = 0; i < NUMBERCOS; i++)
    {
        for (int j = 0; j < NUMNAVIOS; j++)
        {
            if (s.MAT[i][j] != -1) //se o navio é atendido
            {
                if (vetTerminoAtendimento[i] > tempChegada[s.MAT[i][j]]) // se o navio chegou antes do termino de atendimento ou antes do berço abrir
                {
                    matInicioAtendimento[i][j] = vetTerminoAtendimento[i]; //inicio do atendimento do navio é após o termino do anterior
                    vetTerminoAtendimento[i] += MAT_ATENDIMENTO[i][j];     //termino do atendimento será somado com abertura do berco
                    matTerminoAtendimento[i][j] = vetTerminoAtendimento[i];
                }
                else //se o navio chegou depois do berço abrir.
                {
                    matInicioAtendimento[i][j] = tempChegada[s.MAT[i][j]];                                  //inicio do atendimento do navio é após o termino do anterior
                    vetTerminoAtendimento[i] += tempChegada[s.MAT[i][j]] + MAT_ATENDIMENTO[i][s.MAT[i][j]]; //termino de atendimento
                    matTerminoAtendimento[i][j] = vetTerminoAtendimento[i];
                }
            }
        }
    }

    //calcula valor da FO.
    for (int i = 0; i < NUMBERCOS; i++)
    {
        for (int j = 0; j < NUMNAVIOS; j++)
        {
            if (matInicioAtendimento[i][j] != 0)
                s.fo += matInicioAtendimento[i][j] - tempChegada[s.MAT[i][j]] + MAT_ATENDIMENTO[i][j];
            + (PESO_TFBERCO * MAX(0, vetTerminoAtendimento[i] - tempFechamento[i]))
            + (PESO_TLNAVIO * MAX(0, matTerminoAtendimento[i][j] - tempSaida[j])); //penalizar se estourou o tempo berco, do navio
        }
    }
}

int totalViolacoesBercos(Solucao s)
{
    int total = 0;
    for (int i = 0; i < NUMBERCOS; i++)
    {      
        if (MAX(0, vetTerminoAtendimento[i] - tempFechamento[i]) != 0)
        total++;
    }
    return total;
}

int totalViolacoesNavios(Solucao s)
{
    int total = 0;
   
    for (int i = 0; i < NUMBERCOS; i++)
    {
        for (int j = 0; j < NUMNAVIOS; j++)
        {
            if (MAX(0, matTerminoAtendimento[i][j] - tempSaida[j]) != 0)
                total++;
        }
    }
    return total;
}

void escreverSol(const Solucao &s, char *arq)
{
    FILE *f;
    if (arq == "")
        f = stdout;
    else
        f = fopen(arq, "w");

    int countBercos = 0;
    int countNavios = 0;
    cout << "< ----------------------------- SOLUÇÃO ---------------------------- >";
    cout << "\n";

    for (int i = 0; i < NUMBERCOS; i++)
    {
        if (s.qtd_navio_no_berco[i] != 0)
            countBercos++;
    }

    cout << "Número de berços utilizados.........................: " << countBercos;
    cout << "\n";

    for (int i = 0; i < NUMBERCOS; i++)
    {
        if (s.qtd_navio_no_berco[i] != 0)
            countNavios += s.qtd_navio_no_berco[i];
    }

    cout << "Número de navios atendidos..........................: " << countNavios;
    cout << "\n";

    cout << "Tempo total de operação.............................: " << s.fo;
    cout << "\n";

    cout << "Total de viol. nas jan. de tempo dos bercos.........: " << totalViolacoesBercos(s);
    cout << "\n";

    cout << "Total de viol. nas jan. de tempo dos navios.........: " << totalViolacoesNavios(s);
    cout << "\n";

    cout << "FO da solução.......................................: " << s.fo;
    cout << "\n";
        
    //qtd navios no berço j.
    for (int i = 0; i < NUMBERCOS; i++)
    {
        cout << "Quantidade de navios atendidos no berço " << i << ": " << s.qtd_navio_no_berco[i] << "\n";
    }
    cout << "\n";

    //inicio de atendimento do navio j no berco i.
    for (int i = 0; i < NUMBERCOS; i++)
    {
        for (int j = 0; j < NUMNAVIOS; j++)
        {
            if (matInicioAtendimento[i][j] != 0)
                cout << "Incio de atendimento do navio " << s.MAT[i][j] << " no berço " << i << ": " << matInicioAtendimento[i][j] << "\n";
        }
        cout << "\n";
    }
    cout << "\n";

    //############Arquivo SOLUCAO##########################

    fprintf(f,"%s", "< ----------------------------- SOLUÇÃO ---------------------------- >\n");

    fprintf(f,"%s %d","Número de berços utilizados.........................: ", countBercos);
    fprintf(f,"%s","\n");

    fprintf(f,"%s %d", "Número de navios atendidos..........................: ", countNavios);
    fprintf(f,"%s","\n");

    fprintf(f,"%s %d", "Tempo total de operação.............................: ", s.fo);
    fprintf(f,"%s","\n");

    fprintf(f,"%s %d", "Total de viol. nas jan. de tempo dos bercos.........: ", totalViolacoesBercos(s));
    fprintf(f,"%s","\n");

    fprintf(f,"%s %d","Total de viol. nas jan. de tempo dos navios.........: ", totalViolacoesNavios(s));
    fprintf(f,"%s","\n");

    fprintf(f,"%s %d","FO da solução.......................................: ", s.fo);
    fprintf(f,"%s","\n\n");
        
    //qtd navios no berço j.
    for (int i = 0; i < NUMBERCOS; i++)
    {
        fprintf(f,"%s %d %s %d %s","Quantidade de navios atendidos no berço " , i , ": ", s.qtd_navio_no_berco[i], "\n");
    }
    fprintf(f,"%s", "\n");

    //inicio de atendimento do navio j no berco i.
    for (int i = 0; i < NUMBERCOS; i++)
    {
        for (int j = 0; j < NUMNAVIOS; j++)
        {
            if (matInicioAtendimento[i][j] != 0)
                fprintf(f,"%s %d %s %d %s %d %s", "Incio de atendimento do navio ", s.MAT[i][j], " no berço ", i , ": " , matInicioAtendimento[i][j] , "\n");
        }
        fprintf(f,"%s", "\n");
    }
    fprintf(f,"%s", "\n");
    
}